import { useMemo, useState } from "react";
import { CheckCircle2, FileUp, ShieldCheck } from "lucide-react";
import { api } from "../../api/client";

const FILE_TYPES = ["PDF", "DOCX", "DOC", "JPG", "JPEG", "PNG", "XLSX", "CSV", "TXT", "PPTX", "ZIP", "OTHER"];

export default function UploadPage({ profile, refresh }) {
  const [file, setFile] = useState(null);
  const [metadata, setMetadata] = useState({
    fileName: "", fileType: "PDF", category: "", department: "",
    documentOwner: "", confidentiality: "INTERNAL", documentDate: "",
    storageLocation: "", tags: "", description: "",
  });
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const remaining = useMemo(() => profile.documentLimit - profile.documentsUsed, [profile]);
  const update = (field, value) => setMetadata((current) => ({ ...current, [field]: value }));

  async function submit(event) {
    event.preventDefault();
    setError(""); setSaving(true); setResult(null);
    const form = new FormData();
    form.append("file", file);
    Object.entries(metadata).forEach(([key, value]) => form.append(key, value));
    try {
      setResult(await api("/documents/upload", { method: "POST", body: form }));
      await refresh();
    } catch (requestError) { setError(requestError.message); }
    finally { setSaving(false); }
  }

  return <div className="upload-layout">
    <section className="panel">
      <h3>Catalogue a document</h3>
      <p className="form-intro">Add useful ownership, classification, and filing details for accurate retrieval.</p>
      <form className="form grid" onSubmit={submit}>
        <label className="drop">
          <input type="file" required onChange={(event) => { const selected = event.target.files[0]; setFile(selected); update("fileName", selected?.name || ""); }} />
          <FileUp/><b>{file ? file.name : "Browse or choose a document"}</b><span>Office files, PDFs, images, archives, and text · Maximum 20 MB</span>
        </label>
        <h4 className="form-section wide">Document identity</h4>
        <Field label="Document name" required value={metadata.fileName} onChange={(v) => update("fileName", v)} />
        <Select label="File type" value={metadata.fileType} options={FILE_TYPES} onChange={(v) => update("fileType", v)} />
        <Field label="Category" required placeholder="e.g. Invoices" value={metadata.category} onChange={(v) => update("category", v)} />
        <Field label="Department" placeholder="e.g. Finance" value={metadata.department} onChange={(v) => update("department", v)} />
        <h4 className="form-section wide">Ownership and access</h4>
        <Field label="Document owner" placeholder="Person or team" value={metadata.documentOwner} onChange={(v) => update("documentOwner", v)} />
        <Select label="Confidentiality" value={metadata.confidentiality} options={["PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED"]} onChange={(v) => update("confidentiality", v)} />
        <h4 className="form-section wide">Filing information</h4>
        <Field type="date" label="Document date" value={metadata.documentDate} onChange={(v) => update("documentDate", v)} />
        <Field label="Storage location" placeholder="e.g. Cabinet A3 or Finance Drive" value={metadata.storageLocation} onChange={(v) => update("storageLocation", v)} />
        <Field label="Search tags" placeholder="tax, annual, approved" value={metadata.tags} onChange={(v) => update("tags", v)} />
        <label className="wide">Description<textarea placeholder="Purpose, contents, parties, or useful context" value={metadata.description} onChange={(e) => update("description", e.target.value)} /></label>
        {error && <div className="error wide">{error}</div>}
        <button className="primary wide" disabled={saving || remaining <= 0}>{saving ? "Saving document…" : "Save and generate document number"}</button>
      </form>
    </section>
    <aside className="tip">
      <ShieldCheck/><b>{remaining} uploads remaining</b><span>{profile.documentsUsed} of {profile.documentLimit} used</span>
      <p>Categories are created automatically. All supplied details can be combined in real-time search.</p>
      {result && <div className="code-result"><CheckCircle2/><small>DOCUMENT SAVED</small><strong>{result.documentCode}</strong><p>Copy this number for instant retrieval.</p></div>}
    </aside>
  </div>;
}

function Field({ label, value, onChange, placeholder = "", type = "text", required = false }) {
  return <label>{label}<input type={type} value={value} placeholder={placeholder} required={required} onChange={(event) => onChange(event.target.value)} /></label>;
}
function Select({ label, value, options, onChange }) {
  return <label>{label}<select value={value} onChange={(event) => onChange(event.target.value)}>{options.map((option) => <option key={option}>{option}</option>)}</select></label>;
}
