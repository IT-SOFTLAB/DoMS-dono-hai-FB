import React, { useEffect, useState } from "react";
import {
  LayoutDashboard,
  Upload,
  Search,
  UserRound,
  LogOut,
  Users,
  ReceiptText,
  FileText,
  Menu,
  X,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Download,
  Trash2,
} from "lucide-react";
import "./styles.css";
import { api, API } from "./api/client";
import { plans } from "./config/plans";
import DocumentUploadPage from "./features/documents/UploadPage";
import DocumentSearchPage from "./features/documents/SearchPage";
function Login({ onLogin }) {
  const [e, setE] = useState("user@gmail.com"),
    [p, setP] = useState("User@123"),
    [err, setErr] = useState("");
  async function submit(x) {
    x.preventDefault();
    try {
      const r = await api("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email: e, password: p }),
      });
      localStorage.setItem("doms_token", r.token);
      localStorage.setItem("doms_user", JSON.stringify(r));
      onLogin(r);
    } catch (z) {
      setErr(z.message);
    }
  }
  return (
    <div className="login">
      <section className="brand-panel">
        <div className="logo">
          <FileText /> DOMS
        </div>
        <div>
          <span className="eyebrow">DOCUMENT INTELLIGENCE</span>
          <h1>
            Your records.
            <br />
            Perfectly placed.
          </h1>
          <p>
            A secure workspace to catalogue, find, and control every important
            document.
          </p>
        </div>
        <small>Organize with clarity · Retrieve with confidence</small>
      </section>
      <section className="login-form">
        <form onSubmit={submit}>
          <div className="mark">
            <ShieldCheck />
          </div>
          <h2>Welcome back</h2>
          <p>Sign in to your document workspace</p>
          <label>
            Email address
            <input
              type="email"
              value={e}
              onChange={(x) => setE(x.target.value)}
              required
            />
          </label>
          <label>
            Password
            <input
              type="password"
              value={p}
              onChange={(x) => setP(x.target.value)}
              required
            />
          </label>
          {err && <div className="error">{err}</div>}
          <button className="primary">Sign in</button>
          <div className="demo">
            <b>Demo accounts</b>
            <button
              type="button"
              onClick={() => {
                setE("admin@gmail.com");
                setP("Admin@123");
              }}
            >
              Super Admin
            </button>
            <button
              type="button"
              onClick={() => {
                setE("user@gmail.com");
                setP("User@123");
              }}
            >
              User
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
function Shell({ user, onLogout }) {
  const admin = user.role === "ROLE_ADMIN";
  const items = admin
    ? [
        ["dashboard", LayoutDashboard, "Overview"],
        ["users", Users, "Manage users"],
        ["subscriptions", ReceiptText, "Subscriptions"],
      ]
    : [
        ["dashboard", LayoutDashboard, "Dashboard"],
        ["upload", Upload, "Upload document"],
        ["search", Search, "Search documents"],
        ["profile", UserRound, "Manage profile"],
      ];
  const [page, setPage] = useState("dashboard"),
    [open, setOpen] = useState(false);
  return (
    <div className="app">
      <aside className={open ? "open" : ""}>
        <div className="logo">
          <FileText /> DOMS{" "}
          <button className="close" onClick={() => setOpen(false)}>
            <X />
          </button>
        </div>
        <nav>
          {items.map(([id, I, l]) => (
            <button
              className={page === id ? "active" : ""}
              onClick={() => {
                setPage(id);
                setOpen(false);
              }}
              key={id}
            >
              <I />
              {l}
            </button>
          ))}
        </nav>
        <div className="account">
          <div className="avatar">{user.fullName?.[0]}</div>
          <div>
            <b>{user.fullName}</b>
            <span>{admin ? "Super Admin" : "Member"}</span>
          </div>
        </div>
        <button className="logout" onClick={onLogout}>
          <LogOut />
          Logout
        </button>
      </aside>
      <main>
        <header>
          <button className="hamb" onClick={() => setOpen(true)}>
            <Menu />
          </button>
          <div>
            <span className="eyebrow">
              {admin ? "ADMIN CONSOLE" : "MY WORKSPACE"}
            </span>
            <h2>{items.find((x) => x[0] === page)?.[2]}</h2>
          </div>
          <div className="header-user">{user.fullName}</div>
        </header>
        <div className="content">
          {admin ? <Admin page={page} /> : <UserPages page={page} />}
        </div>
      </main>
    </div>
  );
}
function Stat({ label, value, sub, tone = "" }) {
  return (
    <div className={"stat " + tone}>
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{sub}</small>
    </div>
  );
}
function Admin({ page }) {
  const [users, setUsers] = useState([]),
    [subs, setSubs] = useState([]),
    [form, setForm] = useState({
      fullName: "",
      email: "",
      password: "",
      role: "ROLE_USER",
    }),
    [edit, setEdit] = useState(null),
    [msg, setMsg] = useState("");
  const load = () =>
    Promise.all([
      api("/admin/users").then(setUsers),
      api("/admin/subscriptions").then(setSubs),
    ]).catch((e) => setMsg(e.message));
  useEffect(() => {
    load();
  }, []);
  async function create(e) {
    e.preventDefault();
    try {
      await api("/admin/create-user", {
        method: "POST",
        body: JSON.stringify(form),
      });
      setForm({ fullName: "", email: "", password: "", role: "ROLE_USER" });
      setMsg("User created with 10 free uploads");
      load();
    } catch (x) {
      setMsg(x.message);
    }
  }
  async function remove(id) {
    if (confirm("Delete this user?")) {
      await api("/admin/users/" + id, { method: "DELETE" });
      load();
    }
  }
  async function save(u) {
    await api("/admin/users/" + u.id, {
      method: "PUT",
      body: JSON.stringify(u),
    });
    setEdit(null);
    load();
  }
  async function decide(id, d) {
    await api(`/admin/subscriptions/${id}/${d}`, { method: "PUT" });
    load();
  }
  if (page === "dashboard")
    return (
      <>
        <div className="stats">
          <Stat
            label="TOTAL USERS"
            value={users.filter((x) => x.role === "ROLE_USER").length}
            sub="Registered accounts"
          />
          <Stat
            label="PENDING REQUESTS"
            value={subs.filter((x) => x.status === "PENDING").length}
            sub="Needs your attention"
            tone="amber"
          />
          <Stat
            label="PLANS SOLD"
            value={subs.filter((x) => x.status === "APPROVED").length}
            sub="Approved subscriptions"
            tone="green"
          />
        </div>
        <Panel title="Recent subscription activity">
          <SubTable rows={subs.slice(0, 6)} decide={decide} />
        </Panel>
      </>
    );
  if (page === "users")
    return (
      <div className="split">
        <Panel title="Create a new user">
          <form className="form" onSubmit={create}>
            <label>
              Full name
              <input
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                required
              />
            </label>
            <label>
              Email
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
              />
            </label>
            <label>
              Temporary password
              <input
                type="password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                minLength="8"
                required
              />
            </label>
            <button className="primary">Create user</button>
            {msg && <p className="notice">{msg}</p>}
          </form>
        </Panel>
        <Panel title={`All users · ${users.length}`}>
          <div className="user-list">
            {users.map((u) => (
              <div className="user-row" key={u.id}>
                <div className="avatar">{u.fullName[0]}</div>
                <div>
                  <b>{u.fullName}</b>
                  <span>
                    {u.email} · {u.documentsUsed}/{u.documentLimit} documents
                  </span>
                </div>
                <button onClick={() => setEdit({ ...u })}>Edit</button>
                {u.role !== "ROLE_ADMIN" && (
                  <button className="danger" onClick={() => remove(u.id)}>
                    <Trash2 />
                  </button>
                )}
              </div>
            ))}
          </div>
        </Panel>
        {edit && (
          <Modal close={() => setEdit(null)}>
            <h3>Edit user</h3>
            <form
              className="form"
              onSubmit={(e) => {
                e.preventDefault();
                save(edit);
              }}
            >
              <label>
                Name
                <input
                  value={edit.fullName}
                  onChange={(e) =>
                    setEdit({ ...edit, fullName: e.target.value })
                  }
                />
              </label>
              <label>
                Email
                <input
                  value={edit.email}
                  onChange={(e) => setEdit({ ...edit, email: e.target.value })}
                />
              </label>
              <label>
                Status
                <select
                  value={String(edit.enabled)}
                  onChange={(e) =>
                    setEdit({ ...edit, enabled: e.target.value === "true" })
                  }
                >
                  <option value="true">Active</option>
                  <option value="false">Disabled</option>
                </select>
              </label>
              <button className="primary">Save changes</button>
            </form>
          </Modal>
        )}
      </div>
    );
  return (
    <Panel title="Subscription requests & sales history">
      <SubTable rows={subs} decide={decide} />
    </Panel>
  );
}
function SubTable({ rows, decide }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>User</th>
            <th>Plan</th>
            <th>Credits</th>
            <th>Requested</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id}>
              <td>
                <b>{r.userName}</b>
                <small>{r.email}</small>
              </td>
              <td>{r.plan}</td>
              <td>+{r.documentCredits}</td>
              <td>{new Date(r.requestedAt).toLocaleDateString()}</td>
              <td>
                <span className={"badge " + r.status.toLowerCase()}>
                  {r.status}
                </span>
              </td>
              <td>
                {r.status === "PENDING" && (
                  <div className="actions">
                    <button
                      title="Approve"
                      onClick={() => decide(r.id, "approve")}
                    >
                      <CheckCircle2 />
                    </button>
                    <button
                      title="Reject"
                      onClick={() => decide(r.id, "reject")}
                    >
                      <XCircle />
                    </button>
                  </div>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {!rows.length && <Empty text="No subscription activity yet" />}
    </div>
  );
}
function UserPages({ page }) {
  const [profile, setProfile] = useState(null),
    [docs, setDocs] = useState([]),
    [history, setHistory] = useState([]),
    [msg, setMsg] = useState("");
  const load = () =>
    Promise.all([
      api("/user/profile").then(setProfile),
      api("/documents").then(setDocs),
      api("/subscriptions/history").then(setHistory),
    ]).catch((e) => setMsg(e.message));
  useEffect(() => {
    load();
  }, []);
  if (!profile) return <p>{msg || "Loading workspace…"}</p>;
  if (page === "dashboard")
    return (
      <Dashboard
        profile={profile}
        docs={docs}
        history={history}
        refresh={load}
      />
    );
  if (page === "upload") return <DocumentUploadPage profile={profile} refresh={load} />;
  if (page === "search") return <DocumentSearchPage />;
  return <Profile profile={profile} refresh={load} />;
}
function Dashboard({ profile, docs, history, refresh }) {
  return (
    <>
      <div className="welcome">
        <div>
          <span className="eyebrow">GOOD TO SEE YOU</span>
          <h1>{profile.fullName.split(" ")[0]}, your archive is in order.</h1>
          <p>
            {profile.documentLimit - profile.documentsUsed} document uploads
            remain on your {profile.currentPlan.toLowerCase()} plan.
          </p>
        </div>
        <div className="usage">
          <span>
            {profile.documentsUsed} / {profile.documentLimit}
          </span>
          <div>
            <i
              style={{
                width: `${Math.min(100, (profile.documentsUsed / profile.documentLimit) * 100)}%`,
              }}
            />
          </div>
          <small>UPLOAD CAPACITY USED</small>
        </div>
      </div>
      <div className="stats">
        <Stat label="DOCUMENTS" value={docs.length} sub="In your workspace" />
        <Stat
          label="CATEGORIES"
          value={new Set(docs.map((x) => x.category)).size}
          sub="Custom collections"
        />
        <Stat
          label="CURRENT PLAN"
          value={profile.currentPlan}
          sub={`${profile.documentLimit} total capacity`}
          tone="green"
        />
      </div>
      <h3 className="section-title">Increase your capacity</h3>
      <div className="plans">
        {plans.map(([n, c, p]) => (
          <div className="plan" key={n}>
            <span>{n}</span>
            <strong>{c}</strong>
            <small>additional uploads</small>
            <b>{p}</b>
            <button
              onClick={async () => {
                await api("/subscriptions/request/" + n, { method: "POST" });
                refresh();
              }}
            >
              Request plan
            </button>
          </div>
        ))}
      </div>
      <Panel title="Purchase history">
        <SubTable rows={history} />
      </Panel>
    </>
  );
}
function UploadPage({ profile, refresh }) {
  const [f, setF] = useState(null),
    [m, setM] = useState({
      fileName: "",
      fileType: "PDF",
      category: "",
      description: "",
      department: "",
      documentDate: "",
      tags: "",
      referenceNumber: "",
      documentOwner: "",
      confidentiality: "INTERNAL",
      documentStatus: "ACTIVE",
      fiscalYear: "",
      storageLocation: "",
    }),
    [result, setResult] = useState(null),
    [err, setErr] = useState("");
  const input = (key, label, placeholder = "") => (
    <label>
      {label}
      <input
        placeholder={placeholder}
        value={m[key]}
        onChange={(e) => setM({ ...m, [key]: e.target.value })}
      />
    </label>
  );
  async function submit(e) {
    e.preventDefault();
    setErr("");
    const fd = new FormData();
    fd.append("file", f);
    Object.entries(m).forEach(([k, v]) => fd.append(k, v));
    try {
      setResult(await api("/documents/upload", { method: "POST", body: fd }));
      refresh();
    } catch (x) {
      setErr(x.message);
    }
  }
  return (
    <div className="upload-layout">
      <Panel title="Catalogue a document">
        <p className="form-intro">
          Detailed metadata makes every document faster to retrieve.
        </p>
        <form className="form grid" onSubmit={submit}>
          <label className="drop">
            Choose document
            <input
              type="file"
              onChange={(e) => {
                setF(e.target.files[0]);
                setM({ ...m, fileName: e.target.files[0]?.name || "" });
              }}
              required
            />
            <Upload />
            <b>{f ? f.name : "Browse or choose a file"}</b>
            <span>Office files, images, archives and text · Up to 20 MB</span>
          </label>
          <h4 className="form-section wide">Document identity</h4>
          <label>
            Document name
            <input
              value={m.fileName}
              onChange={(e) => setM({ ...m, fileName: e.target.value })}
              required
            />
          </label>
          <label>
            File type
            <select
              value={m.fileType}
              onChange={(e) => setM({ ...m, fileType: e.target.value })}
            >
              {[
                "PDF",
                "DOCX",
                "DOC",
                "JPG",
                "JPEG",
                "PNG",
                "XLSX",
                "CSV",
                "TXT",
                "PPTX",
                "ZIP",
                "OTHER",
              ].map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </label>
          <label>
            Category
            <input
              placeholder="e.g. Invoices"
              value={m.category}
              onChange={(e) => setM({ ...m, category: e.target.value })}
              required
            />
          </label>
          {input("referenceNumber", "Reference number", "e.g. INV-2026-0182")}
          <h4 className="form-section wide">Classification & ownership</h4>
          {input("department", "Department", "e.g. Finance")}
          {input("documentOwner", "Document owner", "Person or team")}
          <label>
            Confidentiality
            <select
              value={m.confidentiality}
              onChange={(e) => setM({ ...m, confidentiality: e.target.value })}
            >
              {["PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED"].map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </label>
          <label>
            Status
            <select
              value={m.documentStatus}
              onChange={(e) => setM({ ...m, documentStatus: e.target.value })}
            >
              {["DRAFT", "ACTIVE", "APPROVED", "ARCHIVED", "EXPIRED"].map(
                (x) => (
                  <option key={x}>{x}</option>
                ),
              )}
            </select>
          </label>
          <h4 className="form-section wide">Dates & filing</h4>
          <label>
            Document date
            <input
              type="date"
              value={m.documentDate}
              onChange={(e) => setM({ ...m, documentDate: e.target.value })}
            />
          </label>
          {input("fiscalYear", "Fiscal year", "e.g. 2026-27")}
          {input("storageLocation", "Storage location", "e.g. Cabinet A3")}
          {input("tags", "Search tags", "tax, annual, approved")}
          <label className="wide">
            Description
            <textarea
              placeholder="Purpose, contents, key parties, or useful context"
              value={m.description}
              onChange={(e) => setM({ ...m, description: e.target.value })}
            />
          </label>
          {err && <div className="error wide">{err}</div>}
          <button className="primary wide">
            Save & generate document number
          </button>
        </form>
      </Panel>
      <aside className="tip">
        <b>Capacity</b>
        <span>
          {profile.documentsUsed} of {profile.documentLimit} used
        </span>
        <p>
          Every field becomes searchable. New categories are created
          automatically.
        </p>
        {result && (
          <div className="code-result">
            <CheckCircle2 />
            <small>DOCUMENT SAVED</small>
            <strong>{result.documentCode}</strong>
            <p>Keep this number for instant retrieval.</p>
          </div>
        )}
      </aside>
    </div>
  );
}
function SearchPage() {
  const [mode, setMode] = useState("code"),
    [q, setQ] = useState(""),
    [filters, setFilters] = useState({
      type: "",
      category: "",
      department: "",
      name: "",
    }),
    [results, setResults] = useState([]),
    [err, setErr] = useState("");
  async function go(e) {
    e.preventDefault();
    try {
      setErr("");
      if (mode === "code")
        setResults([await api("/documents/code/" + encodeURIComponent(q))]);
      else {
        const p = new URLSearchParams(
          Object.entries(filters).filter((x) => x[1]),
        );
        setResults(await api("/documents/advanced-search?" + p));
      }
    } catch (x) {
      setResults([]);
      setErr(x.message);
    }
  }
  return (
    <>
      <div className="tabs">
        <button
          className={mode === "code" ? "active" : ""}
          onClick={() => setMode("code")}
        >
          Unique document number
        </button>
        <button
          className={mode === "manual" ? "active" : ""}
          onClick={() => setMode("manual")}
        >
          Manual filters
        </button>
      </div>
      <Panel
        title={
          mode === "code"
            ? "Find one document instantly"
            : "Filter your document archive"
        }
      >
        <form className="search-form" onSubmit={go}>
          {mode === "code" ? (
            <input
              placeholder="DOC-INVO-PDF-U002-XXXXXXXX"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              required
            />
          ) : (
            <>
              {["name", "category", "department"].map((k) => (
                <input
                  key={k}
                  placeholder={k[0].toUpperCase() + k.slice(1)}
                  value={filters[k]}
                  onChange={(e) =>
                    setFilters({ ...filters, [k]: e.target.value })
                  }
                />
              ))}
              <select
                value={filters.type}
                onChange={(e) =>
                  setFilters({ ...filters, type: e.target.value })
                }
              >
                <option value="">All file types</option>
                {["PDF", "DOCX", "JPG", "PNG", "XLSX", "OTHER"].map((x) => (
                  <option>{x}</option>
                ))}
              </select>
            </>
          )}
          <button className="primary">
            <Search /> Search
          </button>
        </form>
        {err && <div className="error">{err}</div>}
      </Panel>
      <div className="results">
        {results.map((d) => (
          <div className="doc" key={d.id}>
            <div className="file-icon">{d.fileType}</div>
            <div>
              <b>{d.fileName}</b>
              <span>
                {d.category} · {d.department || "No department"}
              </span>
              <code>{d.documentCode}</code>
            </div>
            <a
              href={`${API}/documents/download/${d.id}`}
              onClick={(e) => {
                e.preventDefault();
                fetch(`${API}/documents/download/${d.id}`, {
                  headers: {
                    Authorization: `Bearer ${localStorage.getItem("doms_token")}`,
                  },
                })
                  .then((r) => r.blob())
                  .then((b) => {
                    const a = document.createElement("a");
                    a.href = URL.createObjectURL(b);
                    a.download = d.fileName;
                    a.click();
                  });
              }}
            >
              <Download />
            </a>
          </div>
        ))}
      </div>
    </>
  );
}
function SearchPageV2() {
  const blank = {
    type: "",
    category: "",
    department: "",
    name: "",
    owner: "",
    confidentiality: "",
    status: "",
    fiscalYear: "",
    referenceNumber: "",
    tags: "",
  };
  const [mode, setMode] = useState("code"),
    [q, setQ] = useState(""),
    [filters, setFilters] = useState(blank),
    [results, setResults] = useState([]),
    [err, setErr] = useState(""),
    [loading, setLoading] = useState(false);
  async function find(current) {
    setLoading(true);
    try {
      const p = new URLSearchParams(
        Object.entries(current).filter(([, v]) => v),
      );
      setResults(await api("/documents/advanced-search?" + p));
      setErr("");
    } catch (e) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    if (mode !== "manual") return;
    const timer = setTimeout(() => find(filters), 250);
    return () => clearTimeout(timer);
  }, [mode, filters]);
  async function byCode(e) {
    e.preventDefault();
    try {
      setResults([await api("/documents/code/" + encodeURIComponent(q))]);
      setErr("");
    } catch (x) {
      setResults([]);
      setErr(x.message);
    }
  }
  async function remove(id) {
    if (!confirm("Permanently delete this document and its stored file?"))
      return;
    try {
      await api("/documents/" + id, { method: "DELETE" });
      setResults((r) => r.filter((d) => d.id !== id));
    } catch (x) {
      setErr(x.message);
    }
  }
  const change = (k, v) => setFilters({ ...filters, [k]: v });
  return (
    <>
      <div className="tabs">
        <button
          className={mode === "code" ? "active" : ""}
          onClick={() => setMode("code")}
        >
          Unique document number
        </button>
        <button
          className={mode === "manual" ? "active" : ""}
          onClick={() => setMode("manual")}
        >
          Real-time filters
        </button>
      </div>
      <Panel
        title={
          mode === "code"
            ? "Find one document instantly"
            : "Filter your archive in real time"
        }
      >
        {mode === "code" ? (
          <form className="search-form" onSubmit={byCode}>
            <input
              placeholder="DOC-INVO-PDF-U002-XXXXXXXX"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              required
            />
            <button className="primary">
              <Search /> Search
            </button>
          </form>
        ) : (
          <>
            <div className="filter-grid">
              {[
                ["name", "Document name"],
                ["category", "Category"],
                ["department", "Department"],
                ["owner", "Owner"],
                ["referenceNumber", "Reference number"],
                ["fiscalYear", "Fiscal year"],
                ["tags", "Tags"],
              ].map(([k, l]) => (
                <label key={k}>
                  {l}
                  <input
                    value={filters[k]}
                    onChange={(e) => change(k, e.target.value)}
                    placeholder={"Filter by " + l.toLowerCase()}
                  />
                </label>
              ))}
              <label>
                File type
                <select
                  value={filters.type}
                  onChange={(e) => change("type", e.target.value)}
                >
                  <option value="">All types</option>
                  {[
                    "PDF",
                    "DOCX",
                    "DOC",
                    "JPG",
                    "JPEG",
                    "PNG",
                    "XLSX",
                    "CSV",
                    "TXT",
                    "PPTX",
                    "ZIP",
                    "OTHER",
                  ].map((x) => (
                    <option key={x}>{x}</option>
                  ))}
                </select>
              </label>
              <label>
                Confidentiality
                <select
                  value={filters.confidentiality}
                  onChange={(e) => change("confidentiality", e.target.value)}
                >
                  <option value="">All levels</option>
                  {["PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED"].map(
                    (x) => (
                      <option key={x}>{x}</option>
                    ),
                  )}
                </select>
              </label>
              <label>
                Status
                <select
                  value={filters.status}
                  onChange={(e) => change("status", e.target.value)}
                >
                  <option value="">All statuses</option>
                  {["DRAFT", "ACTIVE", "APPROVED", "ARCHIVED", "EXPIRED"].map(
                    (x) => (
                      <option key={x}>{x}</option>
                    ),
                  )}
                </select>
              </label>
            </div>
            <div className="filter-footer">
              <span>
                {loading
                  ? "Searching…"
                  : results.length +
                    " document" +
                    (results.length === 1 ? "" : "s") +
                    " found"}
              </span>
              <button onClick={() => setFilters(blank)}>
                Clear all filters
              </button>
            </div>
          </>
        )}
        {err && <div className="error">{err}</div>}
      </Panel>
      <div className="results">
        {results.map((d) => (
          <div className="doc" key={d.id}>
            <div className="file-icon">{d.fileType}</div>
            <div>
              <b>{d.fileName}</b>
              <span>
                {d.category || "Uncategorized"} ·{" "}
                {d.department || "No department"} ·{" "}
                {d.documentOwner || "No owner"}
              </span>
              <div className="doc-meta">
                <em>{d.confidentiality || "INTERNAL"}</em>
                <em>{d.documentStatus || "ACTIVE"}</em>
                {d.referenceNumber && <em>Ref: {d.referenceNumber}</em>}
              </div>
              <code>{d.documentCode}</code>
            </div>
            <div className="doc-actions">
              <a
                title="Download"
                href={`${API}/documents/download/${d.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  fetch(`${API}/documents/download/${d.id}`, {
                    headers: {
                      Authorization: `Bearer ${localStorage.getItem("doms_token")}`,
                    },
                  })
                    .then((r) => r.blob())
                    .then((b) => {
                      const a = document.createElement("a");
                      a.href = URL.createObjectURL(b);
                      a.download = d.fileName;
                      a.click();
                    });
                }}
              >
                <Download />
              </a>
              <button
                className="delete-doc"
                title="Delete document"
                onClick={() => remove(d.id)}
              >
                <Trash2 />
              </button>
            </div>
          </div>
        ))}
        {!loading && !results.length && mode === "manual" && (
          <Empty text="No documents match the selected filters" />
        )}
      </div>
    </>
  );
}
function Profile({ profile, refresh }) {
  const [f, setF] = useState({ ...profile }),
    [pw, setPw] = useState({ currentPassword: "", newPassword: "" }),
    [msg, setMsg] = useState("");
  return (
    <div className="split">
      <Panel title="Profile details">
        <form
          className="form"
          onSubmit={async (e) => {
            e.preventDefault();
            await api("/user/profile", {
              method: "PUT",
              body: JSON.stringify({ ...f, role: "ROLE_USER", enabled: true }),
            });
            setMsg("Profile updated");
            refresh();
          }}
        >
          <label>
            Full name
            <input
              value={f.fullName}
              onChange={(e) => setF({ ...f, fullName: e.target.value })}
            />
          </label>
          <label>
            Email
            <input
              value={f.email}
              onChange={(e) => setF({ ...f, email: e.target.value })}
            />
          </label>
          <button className="primary">Save profile</button>
        </form>
      </Panel>
      <Panel title="Security & subscription">
        <div className="profile-plan">
          <b>{profile.currentPlan} PLAN</b>
          <strong>{profile.documentLimit - profile.documentsUsed}</strong>
          <span>uploads remaining</span>
        </div>
        <form
          className="form"
          onSubmit={async (e) => {
            e.preventDefault();
            try {
              await api("/user/change-password", {
                method: "PUT",
                body: JSON.stringify(pw),
              });
              setMsg("Password changed");
            } catch (x) {
              setMsg(x.message);
            }
          }}
        >
          <label>
            Current password
            <input
              type="password"
              value={pw.currentPassword}
              onChange={(e) =>
                setPw({ ...pw, currentPassword: e.target.value })
              }
            />
          </label>
          <label>
            New password
            <input
              type="password"
              minLength="8"
              value={pw.newPassword}
              onChange={(e) => setPw({ ...pw, newPassword: e.target.value })}
            />
          </label>
          <button>Change password</button>
          {msg && <p className="notice">{msg}</p>}
        </form>
      </Panel>
    </div>
  );
}
function Panel({ title, children }) {
  return (
    <section className="panel">
      <h3>{title}</h3>
      {children}
    </section>
  );
}
function Empty({ text }) {
  return (
    <div className="empty">
      <FileText />
      <p>{text}</p>
    </div>
  );
}
function Modal({ close, children }) {
  return (
    <div className="modal" onMouseDown={close}>
      <div onMouseDown={(e) => e.stopPropagation()}>
        <button className="close" onClick={close}>
          <X />
        </button>
        {children}
      </div>
    </div>
  );
}
function readStoredUser() {
  try {
    const value = localStorage.getItem("doms_user");
    if (!value) return null;
    const user = JSON.parse(value);
    return user && user.token && user.role ? user : null;
  } catch {
    localStorage.removeItem("doms_user");
    localStorage.removeItem("doms_token");
    return null;
  }
}
export default function App() {
  const [u, setU] = useState(readStoredUser);
  return u ? (
    <Shell
      user={u}
      onLogout={() => {
        localStorage.removeItem("doms_user");
        localStorage.removeItem("doms_token");
        setU(null);
      }}
    />
  ) : (
    <Login onLogin={setU} />
  );
}
