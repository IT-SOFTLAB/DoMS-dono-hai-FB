package com.doms.doms.serviceImpl;

import com.doms.doms.dto.*;
import com.doms.doms.entity.*;
import com.doms.doms.repository.*;
import com.doms.doms.service.*;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.time.LocalDateTime;
import java.util.*;

@Service @RequiredArgsConstructor
public class DocumentServiceImpl implements DocumentService {
    private final DocumentRepository documents;
    private final UserRepository users;
    private final FileStorageService files;

    private User current(){return users.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName()).orElseThrow(()->new RuntimeException("User not found"));}
    private Document owned(Long id){User u=current(); return u.getRole()==Role.ROLE_ADMIN?documents.findById(id).orElseThrow(()->new RuntimeException("Document not found")):documents.findByUploadedByAndId(u,id).orElseThrow(()->new RuntimeException("Document not found or access denied"));}
    private DocumentResponseDTO dto(Document d){User u=d.getUploadedBy();return new DocumentResponseDTO(d.getId(),d.getFileName(),d.getFilePath(),d.getFileType(),d.getFileSize(),d.getDescription(),new UserResponseDTO(u.getId(),u.getFullName(),u.getEmail(),u.getRole()),d.getDocumentCode(),d.getCategory(),d.getDepartment(),d.getDocumentDate(),d.getTags(),d.getUploadedAt(),d.getReferenceNumber(),d.getDocumentOwner(),d.getConfidentiality(),d.getDocumentStatus(),d.getFiscalYear(),d.getStorageLocation());}

    public DocumentResponseDTO uploadDocument(MultipartFile file, DocumentRequest m){
        User u=current(); long used=documents.countByUploadedBy(u); if(used>=u.getDocumentLimit()) throw new RuntimeException("Document limit reached. Request a subscription plan to add more uploads.");
        String category=clean(m.getCategory(),"GENERAL"); String type=clean(m.getFileType(),extension(file.getOriginalFilename()));
        String code=code(category,type,u.getId()); String stored=files.saveFile(file);
        Document d=Document.builder().fileName(clean(m.getFileName(),file.getOriginalFilename())).filePath(stored).fileType(type.toUpperCase()).fileSize(file.getSize()).description(m.getDescription()).category(category).department(m.getDepartment()).documentDate(m.getDocumentDate()).tags(m.getTags()).referenceNumber(m.getReferenceNumber()).documentOwner(m.getDocumentOwner()).confidentiality(clean(m.getConfidentiality(),"INTERNAL")).documentStatus(clean(m.getDocumentStatus(),"ACTIVE")).fiscalYear(m.getFiscalYear()).storageLocation(m.getStorageLocation()).documentCode(code).uploadedAt(LocalDateTime.now()).uploadedBy(u).build();
        Document saved=documents.save(d); u.setDocumentsUsed((int)documents.countByUploadedBy(u)); users.save(u); return dto(saved);
    }
    private String clean(String v,String fallback){return v==null||v.isBlank()?fallback:v.trim();}
    private String extension(String n){int i=n==null?-1:n.lastIndexOf('.');return i<0?"FILE":n.substring(i+1);}
    private String code(String category,String type,Long uid){String a=category.replaceAll("[^A-Za-z0-9]","").toUpperCase(); if(a.length()>4)a=a.substring(0,4); String b=type.replaceAll("[^A-Za-z0-9]","").toUpperCase(); if(b.length()>4)b=b.substring(0,4); return String.format("DOC-%s-%s-U%03d-%s",a,b,uid,UUID.randomUUID().toString().substring(0,8).toUpperCase());}
    public List<DocumentResponseDTO> getAllDocuments(){User u=current();return (u.getRole()==Role.ROLE_ADMIN?documents.findAll():documents.findByUploadedBy(u)).stream().map(this::dto).toList();}
    public DocumentResponseDTO getDocumentById(Long id){return dto(owned(id));}
    public void deleteDocument(Long id){Document d=owned(id);files.deleteFile(d.getFilePath());documents.delete(d);User u=d.getUploadedBy();u.setDocumentsUsed((int)documents.countByUploadedBy(u));users.save(u);}
    public DocumentResponseDTO updateDocument(Long id,DocumentRequest m){Document d=owned(id);if(m.getFileName()!=null)d.setFileName(m.getFileName());if(m.getFileType()!=null)d.setFileType(m.getFileType());if(m.getCategory()!=null)d.setCategory(m.getCategory());if(m.getDescription()!=null)d.setDescription(m.getDescription());if(m.getDepartment()!=null)d.setDepartment(m.getDepartment());if(m.getDocumentDate()!=null)d.setDocumentDate(m.getDocumentDate());if(m.getTags()!=null)d.setTags(m.getTags());if(m.getReferenceNumber()!=null)d.setReferenceNumber(m.getReferenceNumber());if(m.getDocumentOwner()!=null)d.setDocumentOwner(m.getDocumentOwner());if(m.getConfidentiality()!=null)d.setConfidentiality(m.getConfidentiality());if(m.getDocumentStatus()!=null)d.setDocumentStatus(m.getDocumentStatus());if(m.getFiscalYear()!=null)d.setFiscalYear(m.getFiscalYear());if(m.getStorageLocation()!=null)d.setStorageLocation(m.getStorageLocation());return dto(documents.save(d));}
    public Resource downloadDocument(Long id){return files.downloadFile(owned(id).getFilePath());}
    public Resource viewDocument(Long id){return files.viewFile(owned(id).getFilePath());}
    public List<DocumentResponseDTO> searchDocuments(String q){return advancedSearch(null,null,null,q,null,null,null,null,null,null);}
    public DocumentResponseDTO searchByCode(String code){User u=current();Document d=u.getRole()==Role.ROLE_ADMIN?documents.findByDocumentCodeIgnoreCase(code).orElseThrow(()->new RuntimeException("Document not found")):documents.findByUploadedByAndDocumentCodeIgnoreCase(u,code).orElseThrow(()->new RuntimeException("Document not found"));return dto(d);}
    public List<DocumentResponseDTO> advancedSearch(String type,String category,String department,String name,String owner,String confidentiality,String status,String fiscalYear,String referenceNumber,String tags){return getAllDocuments().stream().filter(d->matchExact(d.getFileType(),type)).filter(d->matchContains(d.getCategory(),category)).filter(d->matchContains(d.getDepartment(),department)).filter(d->matchContains(d.getFileName(),name)).filter(d->matchContains(d.getDocumentOwner(),owner)).filter(d->matchExact(d.getConfidentiality(),confidentiality)).filter(d->matchExact(d.getDocumentStatus(),status)).filter(d->matchExact(d.getFiscalYear(),fiscalYear)).filter(d->matchContains(d.getReferenceNumber(),referenceNumber)).filter(d->matchContains(d.getTags(),tags)).toList();}
    private boolean matchExact(String value,String filter){return filter==null||filter.isBlank()||Objects.toString(value,"").equalsIgnoreCase(filter);}
    private boolean matchContains(String value,String filter){return filter==null||filter.isBlank()||Objects.toString(value,"").toLowerCase().contains(filter.toLowerCase());}
}
