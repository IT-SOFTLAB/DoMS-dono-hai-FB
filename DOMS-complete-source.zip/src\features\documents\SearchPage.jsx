import { useEffect, useState } from "react";
import { Download, FileText, Search, Trash2, X } from "lucide-react";
import { api, API } from "../../api/client";

const EMPTY_FILTERS = { type: "", category: "", department: "", name: "", owner: "", confidentiality: "", tags: "" };

export default function SearchPage() {
  const [mode, setMode] = useState("code");
  const [code, setCode] = useState("");
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [results, setResults] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const update = (field, value) => setFilters((current) => ({ ...current, [field]: value }));

  useEffect(() => {
    if (mode !== "manual") return;
    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const query = new URLSearchParams(Object.entries(filters).filter(([, value]) => value));
        setResults(await api(`/documents/advanced-search?${query}`)); setError("");
      } catch (requestError) { setError(requestError.message); }
      finally { setLoading(false); }
    }, 250);
    return () => clearTimeout(timer);
  }, [filters, mode]);

  async function searchCode(event) {
    event.preventDefault(); setLoading(true);
    try { setResults([await api(`/documents/code/${encodeURIComponent(code.trim())}`)]); setError(""); }
    catch (requestError) { setResults([]); setError(requestError.message); }
    finally { setLoading(false); }
  }
  async function deleteDocument(document) {
    if (!window.confirm(`Delete “${document.fileName}” permanently?`)) return;
    try { await api(`/documents/${document.id}`, { method: "DELETE" }); setResults((items) => items.filter((item) => item.id !== document.id)); }
    catch (requestError) { setError(requestError.message); }
  }
  async function download(document) {
    try {
      const response = await fetch(`${API}/documents/download/${document.id}`, { headers: { Authorization: `Bearer ${localStorage.getItem("doms_token")}` } });
      if (!response.ok) throw new Error("Download failed");
      const anchor = window.document.createElement("a"); anchor.href = URL.createObjectURL(await response.blob()); anchor.download = document.fileName; anchor.click(); URL.revokeObjectURL(anchor.href);
    } catch (requestError) { setError(requestError.message); }
  }

  return <>
    <div className="tabs"><button className={mode === "code" ? "active" : ""} onClick={() => setMode("code")}>Document number</button><button className={mode === "manual" ? "active" : ""} onClick={() => setMode("manual")}>Real-time filters</button></div>
    <section className="panel"><h3>{mode === "code" ? "Find one document instantly" : "Search your archive"}</h3>
      {mode === "code" ? <form className="search-form" onSubmit={searchCode}><input value={code} onChange={(e) => setCode(e.target.value)} placeholder="DOC-INVO-PDF-U002-XXXXXXXX" required/><button className="primary"><Search/>Search</button></form> : <><div className="filter-grid">
        <Filter label="Document name" value={filters.name} onChange={(v) => update("name", v)}/><Filter label="Category" value={filters.category} onChange={(v) => update("category", v)}/><Filter label="Department" value={filters.department} onChange={(v) => update("department", v)}/><Filter label="Owner" value={filters.owner} onChange={(v) => update("owner", v)}/><Filter label="Tags" value={filters.tags} onChange={(v) => update("tags", v)}/>
        <label>File type<select value={filters.type} onChange={(e) => update("type", e.target.value)}><option value="">All types</option>{["PDF","DOCX","DOC","JPG","JPEG","PNG","XLSX","CSV","TXT","PPTX","ZIP","OTHER"].map((x) => <option key={x}>{x}</option>)}</select></label>
        <label>Confidentiality<select value={filters.confidentiality} onChange={(e) => update("confidentiality", e.target.value)}><option value="">All levels</option>{["PUBLIC","INTERNAL","CONFIDENTIAL","RESTRICTED"].map((x) => <option key={x}>{x}</option>)}</select></label>
      </div><div className="filter-footer"><span>{loading ? "Searching…" : `${results.length} document${results.length === 1 ? "" : "s"} found`}</span><button onClick={() => setFilters(EMPTY_FILTERS)}><X/> Clear filters</button></div></>}
      {error && <div className="error">{error}</div>}
    </section>
    <div className="results">{results.map((document) => <article className="doc" key={document.id}><div className="file-icon">{document.fileType}</div><div><b>{document.fileName}</b><span>{document.category || "Uncategorized"} · {document.department || "No department"} · {document.documentOwner || "No owner"}</span><div className="doc-meta"><em>{document.confidentiality || "INTERNAL"}</em>{document.storageLocation && <em>{document.storageLocation}</em>}</div><code>{document.documentCode}</code></div><div className="doc-actions"><button title="Download" onClick={() => download(document)}><Download/></button><button className="delete-doc" title="Delete" onClick={() => deleteDocument(document)}><Trash2/></button></div></article>)}{!loading && !results.length && mode === "manual" && <div className="empty"><FileText/><p>No documents match these filters.</p></div>}</div>
  </>;
}

function Filter({ label, value, onChange }) { return <label>{label}<input value={value} onChange={(event) => onChange(event.target.value)} placeholder={`Filter by ${label.toLowerCase()}`}/></label>; }
