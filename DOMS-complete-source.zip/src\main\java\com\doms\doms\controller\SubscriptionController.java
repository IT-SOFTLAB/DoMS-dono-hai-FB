package com.doms.doms.controller;
import com.doms.doms.dto.SubscriptionDTO;
import com.doms.doms.entity.*;
import com.doms.doms.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.*;

@RestController @RequestMapping("/api") @RequiredArgsConstructor @CrossOrigin("*")
public class SubscriptionController {
 private final SubscriptionRequestRepository requests; private final UserRepository users;
 private User current(){return users.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName()).orElseThrow();}
 private int credits(String p){return switch(p.toUpperCase()){case "GOLD"->30;case "PLATINUM"->50;case "DIAMOND"->70;default->throw new RuntimeException("Unknown plan");};}
 private SubscriptionDTO dto(SubscriptionRequest r){return SubscriptionDTO.builder().id(r.getId()).userId(r.getUser().getId()).userName(r.getUser().getFullName()).email(r.getUser().getEmail()).plan(r.getPlan()).documentCredits(r.getDocumentCredits()).status(r.getStatus()).requestedAt(r.getRequestedAt()).reviewedAt(r.getReviewedAt()).build();}
 @PostMapping("/subscriptions/request/{plan}") public SubscriptionDTO request(@PathVariable String plan){User u=current();SubscriptionRequest r=SubscriptionRequest.builder().user(u).plan(plan.toUpperCase()).documentCredits(credits(plan)).status("PENDING").requestedAt(LocalDateTime.now()).build();return dto(requests.save(r));}
 @GetMapping("/subscriptions/history") public List<SubscriptionDTO> history(){return requests.findByUserOrderByRequestedAtDesc(current()).stream().map(this::dto).toList();}
 @GetMapping("/admin/subscriptions") public List<SubscriptionDTO> all(){return requests.findAllByOrderByRequestedAtDesc().stream().map(this::dto).toList();}
 @PutMapping("/admin/subscriptions/{id}/{decision}") public ResponseEntity<SubscriptionDTO> decide(@PathVariable Long id,@PathVariable String decision){SubscriptionRequest r=requests.findById(id).orElseThrow(()->new RuntimeException("Request not found"));if(!r.getStatus().equals("PENDING"))throw new RuntimeException("Request already reviewed");String status=decision.equalsIgnoreCase("approve")?"APPROVED":"REJECTED";r.setStatus(status);r.setReviewedAt(LocalDateTime.now());if(status.equals("APPROVED")){User u=r.getUser();u.setDocumentLimit(u.getDocumentLimit()+r.getDocumentCredits());u.setCurrentPlan(r.getPlan());users.save(u);}return ResponseEntity.ok(dto(requests.save(r)));}
}
