package com.doms.doms.controller;

import com.doms.doms.dto.UpdateUserRequest;
import com.doms.doms.dto.UserResponse;
import com.doms.doms.service.UserService;
import com.doms.doms.dto.ChangePasswordRequest;
import com.doms.doms.entity.User;
import com.doms.doms.repository.UserRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
@CrossOrigin("*")
public class UserController {

    private final UserService userService;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // Logged-in User Profile
    @GetMapping("/profile")
    public ResponseEntity<UserResponse> getProfile() {

        return ResponseEntity.ok(userService.getCurrentUserProfile());
    }

    // Update Logged-in User Profile
    @PutMapping("/profile")
    public ResponseEntity<UserResponse> updateProfile(
            @RequestBody UpdateUserRequest request) {

        return ResponseEntity.ok(
                userService.updateCurrentUser(request)
        );
    }
    @PutMapping("/change-password") public ResponseEntity<String> changePassword(@RequestBody ChangePasswordRequest request){User u=userRepository.findByEmail(SecurityContextHolder.getContext().getAuthentication().getName()).orElseThrow();if(!passwordEncoder.matches(request.getCurrentPassword(),u.getPassword()))throw new RuntimeException("Current password is incorrect");if(request.getNewPassword()==null||request.getNewPassword().length()<8)throw new RuntimeException("New password must be at least 8 characters");u.setPassword(passwordEncoder.encode(request.getNewPassword()));userRepository.save(u);return ResponseEntity.ok("Password updated");}
}
